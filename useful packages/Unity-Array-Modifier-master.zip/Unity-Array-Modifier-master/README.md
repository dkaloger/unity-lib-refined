# Unity-Array-Modifier
[![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://github.com/samuelkarabetian/Unity-Array-Modifier/blob/master/LICENSE.md)

An array modifier package for Unity Engine based on the array modifier in Blender. 
The array modifier is a productivity tool that lets you duplicate objects in different ways.
Like in Blender, it can be stacked to create two-dimensional or three-dimensional constructs.

![](https://media.giphy.com/media/RhNIvE6eol7VbPAFaX/giphy.gif)

## Installation
1. Open up the Package Manager (Window->Package Manager)
2. Click the "+" button in the top-left corner and select "Add package from git URL..."
3. Paste in the following URL: https://github.com/samuelkarabetian/Unity-Array-Modifier.git
4. Press the "Add" button