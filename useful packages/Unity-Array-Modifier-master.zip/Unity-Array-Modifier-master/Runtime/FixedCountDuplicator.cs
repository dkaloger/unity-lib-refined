﻿// Copyright(C) 2020 Samuel Karabetian
// This file is part of Unity Array Modifier.

// Unity Array Modifier is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Unity Array Modifier is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Unity Array Modifier.  If not, see<https://www.gnu.org/licenses/>.

using System.Collections.Generic;

namespace UnityArrayModifier
{
    public class FixedCountDuplicator : Duplicator
    {
        public FixedCountDuplicator(ArrayModifier arrayModifier)
            : base(arrayModifier)
        {
        }

        public override List<Duplicate> CreateDuplicates(List<Duplicate> sourceDuplicates)
        {
            var translation = arrayModifier.GetTranslation();
            if (translation.magnitude < ArrayModifier.MIN_TRANSLATION_MAGNITUDE)
            {
                return null;
            }

            var duplicates = new List<Duplicate>();
            var newDuplicates = new List<Duplicate>(sourceDuplicates.Count);

            for (int i = 0; i < arrayModifier.Count - 1; ++i)
            {
                newDuplicates.Clear();
                newDuplicates.AddRange(DuplicatorUtility.CloneDuplicates(sourceDuplicates));

                for (int j = 0; j < newDuplicates.Count; ++j)
                {
                    newDuplicates[j].position += translation * (i + 1f);
                }

                duplicates.AddRange(newDuplicates);
            }

            return duplicates;
        }
    }
}