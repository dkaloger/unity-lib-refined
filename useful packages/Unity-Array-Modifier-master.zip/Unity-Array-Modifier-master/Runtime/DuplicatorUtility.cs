﻿// Copyright(C) 2020 Samuel Karabetian
// This file is part of Unity Array Modifier.

// Unity Array Modifier is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Unity Array Modifier is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Unity Array Modifier.  If not, see<https://www.gnu.org/licenses/>.

using System.Collections.Generic;
using UnityEngine;

namespace UnityArrayModifier
{
    public static class DuplicatorUtility
    {
        public static void RemoveArrayModifiersFrom(GameObject gameObject)
        {
            var arrayModifiers = gameObject.GetComponents<ArrayModifier>();
            for (int i = arrayModifiers.Length - 1; i >= 0; --i)
            {
                Object.DestroyImmediate(arrayModifiers[i]);
            }
        }

        public static List<Duplicate> CreateDuplicates(GameObject gameObject) 
        {
            var arrayModifiers = gameObject.GetComponents<ArrayModifier>();

            var duplicates = new List<Duplicate>();
            var hideFlags = HideFlags.HideInHierarchy | HideFlags.HideInInspector | HideFlags.NotEditable;
            duplicates.Add(new Duplicate(gameObject.transform.position, gameObject.transform.rotation, hideFlags));

            foreach (var am in arrayModifiers)
            {
                if (am.IsScheduledToBeDestroyed)
                {
                    continue;
                }

                var newDuplicates = am.Duplicator.CreateDuplicates(duplicates);
                if (newDuplicates != null && newDuplicates.Count > 0)
                { 
                    duplicates.AddRange(newDuplicates);
                }
            }

            duplicates.RemoveAt(0); // Remove the duplicate of the original GameObject

            return duplicates;
        }

        public static List<Duplicate> CloneDuplicates(List<Duplicate> duplicate)
        {
            List<Duplicate> clones = new List<Duplicate>();

            for (int i = 0; i < duplicate.Count; ++i)
            {
                clones.Add(new Duplicate(duplicate[i]));
            }

            return clones;
        }
    }
}