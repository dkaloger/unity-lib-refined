﻿// Copyright(C) 2020 Samuel Karabetian
// This file is part of Unity Array Modifier.

// Unity Array Modifier is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Unity Array Modifier is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Unity Array Modifier.  If not, see<https://www.gnu.org/licenses/>.

using System.Collections.Generic;
using UnityEngine;

namespace UnityArrayModifier
{
    [ExecuteInEditMode]
    public class ArrayModifier : MonoBehaviour
    {
        [HideInInspector] public FitType fitType = FitType.FixedCount;
        [HideInInspector] public int count = 1;
        [HideInInspector] public Vector3 constantOffset = Vector3.right;
        [HideInInspector] public Vector3 relativeOffset = Vector3.zero;
        [HideInInspector] public float fitLength = 5f;

        private Vector3 size = Vector3.one;
        new private Collider collider = null;
        new private Collider2D collider2D = null;
        private MeshRenderer meshRenderer = null;
        private SpriteRenderer spriteRenderer = null;
        private ArrayModifier previousArrayModifier = null;
        private Duplicator duplicator = null;
        [SerializeField] private List<Duplicate> duplicates = new List<Duplicate>();
        [SerializeField] [HideInInspector] private List<GameObject> instantiatedDuplicates = new List<GameObject>();

        public const float MIN_TRANSLATION_MAGNITUDE = 0.01f;

        // Getters
        public int Count => count;
        public float FitLength => fitLength;
        public Duplicator Duplicator
        {
            get 
            {
                if (duplicator == null)
                {
                    InitializeDuplicator();
                }

                return duplicator;
            }
        }
        public bool IsFirst => previousArrayModifier == null;
        public List<Duplicate> Duplicates => duplicates;
        public List<GameObject> InstantiatedDuplicates => instantiatedDuplicates;
        public bool IsScheduledToBeDestroyed { get; private set; } = false;
        public int Id { get; private set; } = 0;

        public void ClearDuplicates()
        {
            duplicates.Clear();

            for (int i = instantiatedDuplicates.Count - 1; i >= 0; --i)
            {
                DestroyImmediate(instantiatedDuplicates[i]);
            }

            instantiatedDuplicates.Clear();
        }

        public void Refresh()
        {
            GetPreviousArrayModifier();

            if (!IsFirst)
            {
                previousArrayModifier.Refresh();
                return;
            }

            ClearDuplicates();
            InitializeDuplicator();
            duplicates = DuplicatorUtility.CreateDuplicates(gameObject);
            InstantiateDuplicates();
        }

        private void InstantiateDuplicates() 
        {
            var prefab = Object.Instantiate(this.gameObject);
            var duplicateBehaviour = prefab.AddComponent<DuplicateBehaviour>();
            duplicateBehaviour.Initialize(++Id, this);
            DuplicatorUtility.RemoveArrayModifiersFrom(prefab);

            foreach (var duplicate in duplicates)
            {
                var duplicateGameObject = Object.Instantiate(prefab);
                duplicateGameObject.transform.position = duplicate.position;
                duplicateGameObject.transform.rotation = duplicate.rotation;
                duplicateGameObject.hideFlags = duplicate.hideFlags;

                instantiatedDuplicates.Add(duplicateGameObject);

                duplicate.gameObject = duplicateGameObject;
            }

            DestroyImmediate(prefab);
        }

        private void InitializeComponents()
        {
            if (meshRenderer == null) meshRenderer = GetComponent<MeshRenderer>();
            if (collider == null) collider = GetComponent<Collider>();
            if (spriteRenderer == null) spriteRenderer = GetComponent<SpriteRenderer>();
            if (collider2D == null) collider2D = GetComponent<Collider2D>();
        }

        private void DetermineSize()
        {
            InitializeComponents();

            if (meshRenderer != null)
            {
                size = meshRenderer.bounds.size;
            }
            else if (spriteRenderer != null)
            {
                size = spriteRenderer.bounds.size;
            }
            else if (collider != null)
            {
                size = collider.bounds.size;
            }
            else if (collider2D != null)
            {
                size = collider2D.bounds.size;
            }
            else
            {
                size = transform.localScale;
            }
        }

        public Vector3 GetTranslation()
        {
            DetermineSize();

            var relativeOffsetInWorldSpace = transform.TransformVector(relativeOffset);
            Vector3 translation = constantOffset +
                new Vector3(relativeOffsetInWorldSpace.x * size.x / transform.localScale.x,
                            relativeOffsetInWorldSpace.y * size.y / transform.localScale.y,
                            relativeOffsetInWorldSpace.z * size.z / transform.localScale.z);

            return translation;
        }

        private void OnDestroy()
        {
            IsScheduledToBeDestroyed = true;
            ClearDuplicates();

            if (previousArrayModifier != null)
            {
                previousArrayModifier.Refresh();
            }
        }

        private void Update()
        {
            if (Application.isEditor)
            {
                EditorUpdate();
            }
        }

        private void GetPreviousArrayModifier()
        {
            var arrayModifiers = GetComponents<ArrayModifier>();

            for (int i = 0; i < arrayModifiers.Length; ++i)
            {
                if (arrayModifiers[i] == this)
                {
                    if ((i - 1) >= 0) previousArrayModifier = arrayModifiers[i - 1];
                }
            }
        }

        public void InitializeDuplicator()
        {
            switch (fitType)
            {
                case FitType.FixedCount:
                    duplicator = new FixedCountDuplicator(this);
                    break;
                case FitType.Length:
                    duplicator = new LengthDuplicator(this);
                    break;
                default:
                    Debug.LogError("ArrayModifier Error: Unknown FitType");
                    break;
            }
        }

        private void EditorUpdate() 
        {
            if (transform.hasChanged)
            {
                Refresh();
                transform.hasChanged = false;
            }
        }
    }
}