﻿// Copyright(C) 2020 Samuel Karabetian
// This file is part of Unity Array Modifier.

// Unity Array Modifier is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Unity Array Modifier is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Unity Array Modifier.  If not, see<https://www.gnu.org/licenses/>.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using NUnit.Framework;
using UnityArrayModifier;

public class ArrayModifierTest
{
    [Test]
    public void CanCreateFixedCountDuplicates() 
    {
        var arrayModifier = new GameObject().AddComponent<ArrayModifier>();
        arrayModifier.fitType = FitType.FixedCount;
        arrayModifier.constantOffset = Vector3.right;
        arrayModifier.count = 3;
        arrayModifier.Refresh();

        Assert.AreEqual(arrayModifier.Duplicates.Count, arrayModifier.Count - 1);
        Assert.AreEqual(arrayModifier.Duplicates[0].rotation, arrayModifier.transform.rotation);
        Assert.AreEqual(arrayModifier.Duplicates[0].position, arrayModifier.transform.position + arrayModifier.constantOffset * 1f);
        Assert.AreEqual(arrayModifier.Duplicates[1].rotation, arrayModifier.transform.rotation);
        Assert.AreEqual(arrayModifier.Duplicates[1].position, arrayModifier.transform.position + arrayModifier.constantOffset * 2f);
    }

    [Test]
    public void CanStackTwoFixedCountArrayModifiers() 
    {
        var gameObject = new GameObject();

        var firstArrayModifier = gameObject.AddComponent<ArrayModifier>();
        firstArrayModifier.fitType = FitType.FixedCount;
        firstArrayModifier.count = 2;

        var secondArrayModifier = gameObject.AddComponent<ArrayModifier>();
        secondArrayModifier.fitType = FitType.FixedCount;
        secondArrayModifier.count = 2;

        firstArrayModifier.Refresh();

        var expectedDuplicateCount = (firstArrayModifier.count * secondArrayModifier.count) - 1;
        Assert.AreEqual(firstArrayModifier.Duplicates.Count, expectedDuplicateCount);
    }

    [Test]
    public void CanCreateFitLengthDuplicates()
    {
        var arrayModifier = new GameObject().AddComponent<ArrayModifier>();
        arrayModifier.fitType = FitType.Length;
        arrayModifier.constantOffset = Vector3.right;
        arrayModifier.fitLength = 3f;
        arrayModifier.Refresh();

        Assert.AreEqual(arrayModifier.Duplicates.Count, 2);
        Assert.AreEqual(arrayModifier.Duplicates[0].rotation, arrayModifier.transform.rotation);
        Assert.AreEqual(arrayModifier.Duplicates[0].position, arrayModifier.transform.position + arrayModifier.constantOffset * 1f);
        Assert.AreEqual(arrayModifier.Duplicates[1].rotation, arrayModifier.transform.rotation);
        Assert.AreEqual(arrayModifier.Duplicates[1].position, arrayModifier.transform.position + arrayModifier.constantOffset * 2f);
    }

    [Test]
    public void CanClearDuplicates() 
    {
        var arrayModifier = new GameObject().AddComponent<ArrayModifier>();
        arrayModifier.fitType = FitType.FixedCount;
        arrayModifier.count = 5;
        arrayModifier.Refresh();
        arrayModifier.ClearDuplicates();

        Assert.AreEqual(arrayModifier.Duplicates.Count, 0);
    }

    [Test]
    public void CanInstantiateDuplicates() 
    {
        var arrayModifier = new GameObject().AddComponent<ArrayModifier>();
        arrayModifier.fitType = FitType.FixedCount;
        arrayModifier.count = 5;
        arrayModifier.Refresh();

        Assert.AreEqual(arrayModifier.InstantiatedDuplicates.Count, arrayModifier.Count - 1);
    }

    [Test]
    public void CanInitializeDuplicator() 
    {
        var arrayModifier = new GameObject().AddComponent<ArrayModifier>();
        arrayModifier.fitType = FitType.Length;
        arrayModifier.InitializeDuplicator();

        Assert.AreEqual(arrayModifier.Duplicator.GetType(), typeof(LengthDuplicator));
    }

    [Test]
    public void CanRemoveDuplicatesOnDestroyGameObject() 
    {
        var arrayModifier = new GameObject().AddComponent<ArrayModifier>();
        arrayModifier.fitType = FitType.FixedCount;
        arrayModifier.count = 5;
        arrayModifier.Refresh();
        Object.DestroyImmediate(arrayModifier.gameObject);

        Assert.AreEqual(arrayModifier.Duplicates.Count, 0);
    }

    [Test]
    public void CanRemoveArrayModifiersFromGameObject() 
    {
        var gameObject = new GameObject();
        gameObject.AddComponent<ArrayModifier>();
        gameObject.AddComponent<ArrayModifier>();
        gameObject.AddComponent<ArrayModifier>();
        DuplicatorUtility.RemoveArrayModifiersFrom(gameObject);
        var arrayModifiers = gameObject.GetComponents<ArrayModifier>();

        Assert.AreEqual(arrayModifiers.Length, 0);
    }
}